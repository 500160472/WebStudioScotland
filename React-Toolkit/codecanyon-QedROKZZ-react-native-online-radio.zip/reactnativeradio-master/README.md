# React Native Online Radio

Online radio template for Envato Market.

# project DOCUMENTATION

Please, to setup your project access the DOCUMENTATION page on "{projectName}/docs/index" file.  

I'll be glad to help you if you have any questions relating to this application template. No guarantees, but I'll do my best to assist you.
