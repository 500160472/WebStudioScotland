const alertBoxState = {
  visible: false,
  title: null,
  message: null,
  buttonsType: 0,
  pressYes: () => {},
  pressNo: () => {},
  pressOk: () => {},
};

export default alertBoxState;
